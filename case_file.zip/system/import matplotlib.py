import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np

# Define points based on provided coordinates
points = np.array([
    [0, 0, 0], [2, 0, 0], [3, 0, 0], [5, 0, 0],
    [5, 5, 0], [3, 5, 0], [2, 5, 0], [0, 5, 0],
    [0, 0, 0.01], [2, 0, 0.01], [3, 0, 0.01], [5, 0, 0.01],
    [5, 5, 0.01], [3, 5, 0.01], [2, 5, 0.01], [0, 5, 0.01]
])

# Define connectivity for edges
edges = [
    (0, 1), (1, 2), (2, 3), (3, 4), (4, 5), (5, 6), (6, 7), (7, 0), # Bottom face
    (8, 9), (9, 10), (10, 11), (11, 12), (12, 13), (13, 14), (14, 15), (15, 8), # Top face
    (0, 8), (1, 9), (2, 10), (3, 11), (4, 12), (5, 13), (6, 14), (7, 15) # Vertical edges
]

# Create 3D plot
fig = plt.figure(figsize=(8, 8))
ax = fig.add_subplot(111, projection='3d')

# Plot edges
for edge in edges:
    p1, p2 = edge
    ax.plot([points[p1, 0], points[p2, 0]], 
            [points[p1, 1], points[p2, 1]], 
            [points[p1, 2], points[p2, 2]], 'bo-', markersize=5, alpha=0.6)

# Label points
for i, (x, y, z) in enumerate(points):
    ax.text(x, y, z, f'{i}', color='red', fontsize=10)

# Set labels and title
ax.set_xlabel("X-axis")
ax.set_ylabel("Y-axis")
ax.set_zlabel("Z-axis")
ax.set_title("3D Representation of the BlockMesh Geometry")

# Show plot
plt.show()
